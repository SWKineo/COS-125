import Tkinter

def increment():
    global GameNum
    GameNum += 1
    countLabel.config(
        text='Playing Game '+str(GameNum))

GameNum = 1
Player  = 'X'
GameWin = Tkinter.Tk()
topFrame = Tkinter.Frame(GameWin)
midFrame = Tkinter.Frame(GameWin)
botFrame = Tkinter.Frame(GameWin)

countLabel = Tkinter.Label(topFrame,
    text='Playing Game 1', 
    font=('Courier New',30))
countLabel.pack()

turnInfo = Tkinter.Label(midFrame,
    text=Player+' goes!',
    font=('Courier New',30))
turnInfo.pack()

quitBtn = Tkinter.Button(botFrame,
    text='Quit', 
    command=GameWin.destroy,
    font=('Courier New',20))
playBtn = Tkinter.Button(botFrame,
    text='Play Again',
    command=increment,
    font=('Courier New',20))
quitBtn.pack(side='left')
playBtn.pack(side='left')

topFrame.pack()
midFrame.pack()
botFrame.pack()

GameWin.mainloop()
