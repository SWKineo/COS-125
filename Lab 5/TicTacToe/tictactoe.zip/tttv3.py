import Tkinter
def makeMove():
    global Player
    centerBtn.config(text=Player)
    if Player == 'X':
        Player = 'O'
    else:
        Player = 'X'
    turnInfo.config(text=Player+' goes!')
    
def increment():
    global GameNum
    GameNum += 1
    countLabel.config(text='Playing Game '+str(GameNum))

GameNum = 1
Player  = 'X'
GameWin = Tkinter.Tk()
gameFrame = Tkinter.Frame(GameWin)
centerBtn = Tkinter.Button(gameFrame,
    text='?',
    command=makeMove,
    font=('Courier New',30))
centerBtn.pack()

topFrame = Tkinter.Frame(GameWin)
midFrame = Tkinter.Frame(GameWin)
botFrame = Tkinter.Frame(GameWin)

countLabel = Tkinter.Label(topFrame,
    text='Playing Game 1',
    font=('Courier New',30))
countLabel.pack()

turnInfo = Tkinter.Label(midFrame,
    text=Player+' goes!',
    font=('Courier New',30))
turnInfo.pack()

quitBtn = Tkinter.Button(botFrame,text='Quit',
  command=GameWin.destroy,
  font=('Courier New',20))
playBtn = Tkinter.Button(botFrame,
  text='Play Again', 
  command=increment,
  font=('Courier New',20))

quitBtn.pack(side='left')
playBtn.pack(side='left')

gameFrame.pack()
topFrame.pack()
midFrame.pack()
botFrame.pack()

GameWin.mainloop()
