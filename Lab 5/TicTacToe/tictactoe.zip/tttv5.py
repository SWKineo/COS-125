import Tkinter

class cell:
    def __init__(self,cellNum,frame,game):
        self.button = Tkinter.Button(frame,
          text='?',
          command=self.makeMove,
          font=('Courier New',30),
          bg='white')
        self.button.pack()
        self.game = game
        self.value = '?'
        self.num = cellNum

    def makeMove(self):
        if self.value == '?':
            self.button.config(text=self.game.Player)
            self.value = self.game.Player
            self.game.updateGame(self.num)

    def restart(self):
        self.value = '?'
        self.button.config(text='?')

class TTTgame:
    def __init__(self):
        self.gameWin = Tkinter.Tk()
        self.gameFrame = Tkinter.Frame(self.gameWin)
        self.cells = [ ]
        for i in range(9):
            self.cells.append(cell(i,
              self.gameFrame,self))
        self.GameNum = 0
        self.Player = 'X'

        self.topFrame = Tkinter.Frame(self.gameWin)
        self.countLabel = Tkinter.Label(self.topFrame,
          text='Playing Game 0',
          font=('Courier New',30))
        self.countLabel.pack()

        self.midFrame = Tkinter.Frame(self.gameWin)
        self.turnInfo = Tkinter.Label(self.midFrame,
          text=self.Player+' goes!',
          font=('Courier New',30))
        self.turnInfo.pack()
        self.botFrame = Tkinter.Frame(self.gameWin)
        self.quitBtn = Tkinter.Button(self.botFrame,
          text='Quit',
          command=self.gameWin.destroy,
          font=('Courier New',20))
        self.playBtn = Tkinter.Button(self.botFrame,
          text='Play Again',
          command=self.restart,
          font=('Courier New',20))
        self.quitBtn.pack(side='left')
        self.playBtn.pack(side='left')

        self.gameFrame.pack()
        self.topFrame.pack()
        self.midFrame.pack()
        self.botFrame.pack()
        self.gameWin.mainloop()

    def updateGame(self, cell_number):
        #number is a placeholder for the next steps
        if self.Player == 'X':
          self.Player = 'O'
        else:
            self.Player = 'X'
        self.turnInfo.config(
          text=self.Player+' goes!')

    def restart(self):
        self.GameNum += 1
        self.countLabel.config(text='Playing Game '+
          str(self.GameNum))
        self.Player = 'X'
        self.turnInfo.config(text=self.Player+' goes!')
        for c in self.cells:
            c.restart()

TTT = TTTgame()
