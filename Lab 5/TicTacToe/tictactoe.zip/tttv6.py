import Tkinter

class cell:
    def __init__(self,cellNum,frame,game):
        self.button = Tkinter.Button(frame,
          text='?',
          command=self.makeMove,
          font=('Courier New',30),
          bg='white')
        self.button.pack(side='left')
        self.game = game
        self.value = '?'
        self.num = cellNum

    def makeMove(self):
        if self.value == '?':
            self.button.config(text=self.game.Player)
            self.value = self.game.Player
            self.game.updateGame(self.num)

    def restart(self):
        self.value = '?'
        self.button.config(text='?')

class TTTgame:
    def __init__(self):
        self.gameWin = Tkinter.Tk()
        self.gameFrame = Tkinter.Frame(self.gameWin)
        self.cells = [ ]
        self.Row1 = Tkinter.Frame(self.gameWin)
        for i in range(3):
            self.cells.append(cell(i,self.Row1,self))
        self.Row2 = Tkinter.Frame(self.gameWin)
        for i in range(3,6):
            self.cells.append(cell(i,self.Row2,self))
        self.Row3 = Tkinter.Frame(self.gameWin)
        for i in range(6,9):
            self.cells.append(cell(i,self.Row3,self))

        self.GameNum = 0
        self.Player = 'X'

        self.topFrame = Tkinter.Frame(self.gameWin)
        self.countLabel = Tkinter.Label(self.topFrame,
          text='Playing Game 0',
          font=('Courier New',30),
          relief = 'raised',borderwidth=3)
        self.countLabel.pack()

        self.midFrame = Tkinter.Frame(self.gameWin)
        self.turnInfo = Tkinter.Label(self.midFrame,
          text=self.Player+' goes!',
          font=('Courier New',30))
        self.turnInfo.pack()
        self.botFrame = Tkinter.Frame(self.gameWin)
        self.quitBtn = Tkinter.Button(self.botFrame,
          text='Quit',
          command=self.gameWin.destroy,
          font=('Courier New',20))
        self.playBtn = Tkinter.Button(self.botFrame,
          text='Play Again',
          command=self.restart,
          font=('Courier New',20))
        self.quitBtn.pack(side='left')
        self.playBtn.pack(side='left')

        self.Row1.pack()
        self.Row2.pack()
        self.Row3.pack()
        self.gameFrame.pack()
        self.topFrame.pack()
        self.midFrame.pack()
        self.botFrame.pack()
        self.gameWin.mainloop()
        
    def updateGame(self, cell_number):
        #number is a placeholder for the next steps
        if self.Player == 'X':
          self.Player = 'O'
        else:
            self.Player = 'X'
        self.turnInfo.config(
          text=self.Player+' goes!')

    def restart(self):
        self.GameNum += 1
        self.countLabel.config(text='Playing Game '+
          str(self.GameNum))
        self.Player = 'X'
        self.turnInfo.config(text=self.Player+' goes!')
        for c in self.cells:
            c.restart()

TTT = TTTgame()
