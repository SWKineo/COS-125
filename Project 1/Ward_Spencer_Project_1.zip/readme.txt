Please run the game in a terminal window to ensure everything displays properly.

A note on input:
    The 'roll' and 'score' commands are very loose on their formatting requirements.
    
    
    For example,
    
    roll D1, D2
    roll D1, d2
    roll 1, d2
    roll 1 2
    
    will all do exactly the same thing, roll dice one and two.
    
    
    'score' works similarly:
    
    score Three-Of-A-Kind
    score three-of-a-Kind
    score three of a kind
    score Three of a kind
    
    will all work fine.
    